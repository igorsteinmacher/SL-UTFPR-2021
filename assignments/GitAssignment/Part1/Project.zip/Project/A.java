public class A {

	public void bar() {

	}

}
