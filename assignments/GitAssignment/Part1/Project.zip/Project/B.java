public class B {

	public void foo() {

	}

}
