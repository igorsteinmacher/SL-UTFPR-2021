public class B {

	public void bar() {
		A a = new A();
		a.foo();
	}

}
