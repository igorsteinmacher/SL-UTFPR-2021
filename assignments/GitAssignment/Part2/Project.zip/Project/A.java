public class A {

	public void foo() {
		B b = new B();
		b.bar();
	}

}
